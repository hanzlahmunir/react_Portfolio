import React from 'react';

const Education = () => {
    return <h1>Education Page</h1>;
};

export default Education;
