import React from 'react';

const Projects = () => {
    return <h1>Projects Page</h1>;
};

export default Projects;
